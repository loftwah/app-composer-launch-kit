Launch Kit 1.0

Copy the selected PNGs and site.webmanifest to one public directory. Merge head.html into your HTML head; replace its social image placeholder with your actual absolute HTTPS URL and check all paths against your page. Review names, scope and start_url before using the manifest. A manifest is not installation certification.

Open launch-kit.json to inspect settings, source digest, asset purpose and SHA-256 hashes. Original source bytes and EXIF are excluded. To regenerate, reopen this configuration and explicitly select the original image; the source digest must match. PNG encoder bytes may vary between browser engines/versions; the same source/settings/engine should be repeatable.

Composer: open https://composer.loftwah.com/init/launch-kit and explicitly select this ZIP. Review fields before adopting. Export requested, draft import, app application, deployment and served inspection are separate states.

Your artwork remains yours. Only export artwork you are permitted to use. The fictional Night Signal sample is AI-generated, provided under this repository's MIT licence. Space Grotesk font: SIL OFL, Florian Karsten. No ICO or SVG input. Native social rendering and physical installation remain unverified.
